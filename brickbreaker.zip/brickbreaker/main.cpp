#include "SDL.h"
#include "SDL_image.h"
#include <string>

#include "timer.h"
#include "sdlfuncs.h"
#include "bar.h"
#include "globals.h"

int main( int argc, char* args[] )
{
    //Quit flag
    bool quit = false;

    //The frame rate regulator
    Timer fps;

    //Initialize
    if( init() == false ) return 1;

    //Load the files
    if( load_files() == false ) return 1;

	bar blocker;

    //While the user hasn't quit
    while( quit == false )
    {
        //Start the frame timer
        fps.start();

        //While there's events to handle
        while( SDL_PollEvent( &event ) )
        {

			blocker.handlebar();

            //If the user has Xed out the window
			if( event.type == SDL_QUIT)
            {
                quit = true;
            }
			else if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_q)
			{
				quit = true;
			}
        }

		blocker.movebar();

		SDL_FillRect( screen, &screen->clip_rect, SDL_MapRGB( screen->format, 0x00, 0xFF, 0x00 ) );

		blocker.showbar();

        //Update the screen
		if(SDL_Flip(screen) == -1) return 1;

        //Cap the frame rate
        if( fps.get_ticks() < 1000 / FRAMES_PER_SECOND )
        {
            //SDL_Delay( ( 1000 / FRAMES_PER_SECOND ) - fps.get_ticks() );
        }
    }

    //Clean up
    clean_up();

    return 0;
}
