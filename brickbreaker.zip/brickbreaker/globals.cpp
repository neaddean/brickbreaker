#include "globals.h"
#include "SDL.h"
#include "SDL_ttf.h"

SDL_Surface *screen       = NULL;
SDL_Surface *blockerimage = NULL;
SDL_Surface *ballimage    = NULL;

TTF_Font *font = NULL;

const SDL_Color RED   = {225, 0  , 0  };
const SDL_Color BLACK = {0, 0, 0};

SDL_Event event;

const int SCREEN_WIDTH  = 1280;
const int SCREEN_HEIGHT = 900;
const int SCREEN_BPP    = 32;

const int DOT_WIDTH  = 20;
const int DOT_HEIGHT = 20;

const int BAR_WIDTH  = 300;
const int BAR_HEIGHT = 80;

const int FRAMES_PER_SECOND = 60;
