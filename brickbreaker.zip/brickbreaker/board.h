#ifndef board_h
#define board_h

class gameboard
{
	int level;
	
	
public:
	gameboard();

};






#endif