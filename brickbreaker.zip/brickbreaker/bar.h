#ifndef bar_h
#define bar_h

#include <list>
#include <memory>

class ball
{
	int x, y;
	int xVel, yVel;
	bool attatched;

public:

	ball(int X, int Y);
	
	bool moveball(int barx, int bary);
	void showball();
	void ballbar(int barx, int bary);
	void handleball();
	int belowline();
};

class bar
{
	int x ,y;
	int xVel, yVel;
	std::list<ball*> balls;
	bool doit;
	SDL_Surface *ballcount;

public:
	bar();
	void handlebar();
	void movebar();
	void showbar();
};

#endif